<?php
if (!defined('_PS_VERSION_'))
	exit;
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class paynetz extends PaymentModule
{
	public function __construct()
	{

		$this->name = 'paynetz';
		$this->tab = 'payments_gateways';
		$this->version = '2.0.0';
		$this->author = 'ATOM';
		$this->aim_available_currencies = array('INR');
        $this->controllers = array('payment', 'validation','response');
        $this->bootstrap = true;
		parent::__construct();

		$this->displayName = 'NTTDATA Payment Services Payment Gateway';
		$this->description = $this->l('Receive payment with Paynetz');
	}

    public function hookPaymentOptions($params)
    {

        if (!$this->active) {
            return;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $newOption = new PaymentOption();
        //$paymentForm = $this->fetch('module:paynetz/views/templates/hook/paynetz.tpl');
        $newOption->setCallToActionText("Pay by NTTDATA Payment Services Payment Gateway")
            ->setAction($this->context->link->getModuleLink($this->name, 'payment'));
        return [$newOption];
    }


	public function install()
	{
		/*return parent::install() &&
			$this->registerHook('orderConfirmation') &&
			$this->registerHook('payment') &&
			$this->registerHook('header') &&
			$this->registerHook('backOfficeHeader') &&
			Configuration::updateValue('AUTHORIZE_AIM_DEMO', 1) &&
			Configuration::updateValue('AUTHORIZE_AIM_HOLD_REVIEW_OS', _PS_OS_ERROR_);*/
        if (!parent::install() || !$this->registerHook('paymentReturn') || !$this->registerHook('paymentOptions')) {
            return false;
        }
        return true;
	}
	
	public function uninstall()
	{
		Configuration::deleteByName('PAYNETZ_API_MERCHANT_URL');
		Configuration::deleteByName('PAYNETZ_API_SERVER_PORT');
		Configuration::deleteByName('PAYNETZ_API_LOGIN_ID');
		Configuration::deleteByName('PAYNETZ_API_PASSWORD');
		Configuration::deleteByName('PAYNETZ_API_PRODUCT_ID');
        Configuration::deleteByName('PAYNETZ_API_REQ_HASHCODE');
        Configuration::deleteByName('PAYNETZ_API_RES_HASHCODE');
		
        Configuration::deleteByName('PAYNETZ_API_REQ_ENCKEY');
        Configuration::deleteByName('PAYNETZ_API_RES_DECKEY');
        Configuration::deleteByName('PAYNETZ_API_REQ_IVKEY');
		Configuration::deleteByName('PAYNETZ_API_RES_IVKEY');
		Configuration::deleteByName('PAYNETZ_API_JS_CDN_LINK');
		Configuration::deleteByName('PAYNETZ_API_CALLER_AUTH');
		return parent::uninstall();
	}

	/*public function hookOrderConfirmation($params)
	{
		if ($params['objOrder']->module != $this->name)
			return;

		if ($params['objOrder']->getCurrentState() != Configuration::get('PS_OS_ERROR'))
			$this->context->smarty->assign(array('status' => 'ok', 'id_order' => intval($params['objOrder']->id)));
		else
			$this->context->smarty->assign('status', 'failed');

		return $this->display(__FILE__, 'views/templates/hook/orderconfirmation.tpl');
	}*/

	public function hookBackOfficeHeader()
	{
		//$this->context->controller->addJS($this->_path.'js/authorizeaim.js');
		//$this->context->controller->addCSS($this->_path.'css/authorizeaim.css');
	}

	public function getContent()
	{
		$html = '';

		if (Tools::isSubmit('submitModule'))
		{
			Configuration::updateValue('PAYNETZ_API_MERCHANT_URL', Tools::getvalue('api_merchant_url'));
			Configuration::updateValue('PAYNETZ_API_SERVER_PORT', Tools::getvalue('api_server_port'));
			Configuration::updateValue('PAYNETZ_API_LOGIN_ID', Tools::getvalue('api_login_id'));
			Configuration::updateValue('PAYNETZ_API_PASSWORD', Tools::getvalue('api_password'));
			Configuration::updateValue('PAYNETZ_API_PRODUCT_ID', Tools::getvalue('api_product_id'));
            Configuration::updateValue('PAYNETZ_API_REQ_HASHCODE', Tools::getvalue('api_req_hashcode'));
            Configuration::updateValue('PAYNETZ_API_RES_HASHCODE', Tools::getvalue('api_res_hashcode'));
			
            Configuration::updateValue('PAYNETZ_API_REQ_ENCKEY', Tools::getvalue('api_req_enckey'));
            Configuration::updateValue('PAYNETZ_API_RES_DECKEY', Tools::getvalue('api_res_deckey'));
            Configuration::updateValue('PAYNETZ_API_REQ_IVKEY', Tools::getvalue('api_req_IVkey'));
			Configuration::updateValue('PAYNETZ_API_RES_IVKEY', Tools::getvalue('api_res_IVkey'));
			Configuration::updateValue('PAYNETZ_API_JS_CDN_LINK', Tools::getvalue('api_js_cdn_link'));
			Configuration::updateValue('PAYNETZ_API_CALLER_AUTH', Tools::getvalue('api_caller_auth'));
			
			$html .= $this->displayConfirmation($this->l('Configuration updated'));
		}

		// For "Hold for Review" order status
		$currencies = Currency::getCurrencies(false, true);
		$order_states = OrderState::getOrderStates((int)$this->context->cookie->id_lang);

		$this->context->smarty->assign(array(
			'available_currencies' => $this->aim_available_currencies,
			'currencies' => $currencies,
			'module_dir' => $this->_path,
			'order_states' => $order_states,

			'PAYNETZ_API_MERCHANT_URL' => Configuration::get('PAYNETZ_API_MERCHANT_URL'),
			'PAYNETZ_API_SERVER_PORT' => Configuration::get('PAYNETZ_API_SERVER_PORT'),
			'PAYNETZ_API_LOGIN_ID' => Configuration::get('PAYNETZ_API_LOGIN_ID'),
			'PAYNETZ_API_PASSWORD' => Configuration::get('PAYNETZ_API_PASSWORD'),
			'PAYNETZ_API_PRODUCT_ID' => Configuration::get('PAYNETZ_API_PRODUCT_ID'),
            'PAYNETZ_API_REQ_HASH_CODE'=>Configuration::get('PAYNETZ_API_REQ_HASHCODE'),
            'PAYNETZ_API_RES_HASH_CODE'=>Configuration::get('PAYNETZ_API_RES_HASHCODE'),
			
            'PAYNETZ_API_REQ_ENCKEY'=>Configuration::get('PAYNETZ_API_REQ_ENCKEY'),
            'PAYNETZ_API_RES_DECKEY'=>Configuration::get('PAYNETZ_API_RES_DECKEY'),
            'PAYNETZ_API_REQ_IVKEY'=>Configuration::get('PAYNETZ_API_REQ_IVKEY'),
			'PAYNETZ_API_RES_IVKEY'=>Configuration::get('PAYNETZ_API_RES_IVKEY'),
			'PAYNETZ_API_JS_CDN_LINK'=>Configuration::get('PAYNETZ_API_JS_CDN_LINK'),
			'PAYNETZ_API_CALLER_AUTH'=>Configuration::get('PAYNETZ_API_CALLER_AUTH')
		));
				
		return $this->context->smarty->fetch($this->local_path.'views/templates/admin/configuration.tpl');
	}

	/*public function hookPayment($params)
	{

		$currency = Currency::getCurrencyInstance($this->context->cookie->id_currency);

		if (!Validate::isLoadedObject($currency))
			return false;
		
		$isFailed = Tools::getValue('paynetzerror');
		
		
		$this->context->smarty->assign('x_invoice_num', (int)$params['cart']->id);
		$this->context->smarty->assign('isFailed', $isFailed);
		
		return $this->display(__FILE__, 'views/templates/hook/paynetz.tpl');
	}
*/
	public function hookHeader()
	{
		if (_PS_VERSION_ < '1.5')
			Tools::addJS(_PS_JS_DIR_.'jquery/jquery.validate.creditcard2-1.0.1.js');
		else
			$this->context->controller->addJqueryPlugin('validate-creditcard');
	}

	/**
	 * Set the detail of a payment - Call before the validate order init
	 * correctly the pcc object
	 * See Authorize documentation to know the associated key => value
	 * @param array fields
	 */
	public function setTransactionDetail($response)
	{
		// If Exist we can store the details
		if (isset($this->pcc))
		{
			$this->pcc->transaction_id = (string)$response[6];

			// 50 => Card number (XXXX0000)
			$this->pcc->card_number = (string)substr($response[50], -4);

			// 51 => Card Mark (Visa, Master card)
			$this->pcc->card_brand = (string)$response[51];

			$this->pcc->card_expiration = (string)Tools::getValue('x_exp_date');

			// 68 => Owner name
			$this->pcc->card_holder = (string)$response[68];
		}
	}
	
	public function checkCurrency($cart)
	{
		$currency_order = new Currency($cart->id_currency);
		$currencies_module = $this->getCurrency($cart->id_currency);

		if (is_array($currencies_module))
			foreach ($currencies_module as $currency_module)
				if ($currency_order->id == $currency_module['id_currency'])
					return true;
		return false;
	}

	public function hookPaymentReturn($params)
	{

		if (!$this->active)
			return;


		/*$state = $params['objOrder']->getCurrentState();
		if ($state == Configuration::get('PS_OS_BANKWIRE') || $state == Configuration::get('PS_OS_OUTOFSTOCK'))
		{
			$this->smarty->assign(array(
				'total_to_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
				'bankwireDetails' => Tools::nl2br($this->details),
				'bankwireAddress' => Tools::nl2br($this->address),
				'bankwireOwner' => $this->owner,
				'status' => 'ok',
				'id_order' => $params['objOrder']->id
			));
			if (isset($params['objOrder']->reference) && !empty($params['objOrder']->reference))
				$this->smarty->assign('reference', $params['objOrder']->reference);
		}
		else
			$this->smarty->assign('status', 'failed');*/
       // $this->smarty->assign('status', 'failed');
		//return $this->display(__FILE__, 'payment_return.tpl');
	}
	
	
	
	public function hookDisplayPayment($params)
{
    $this->context->controller->addCSS(_MODULE_DIR_.$this->name.'/views/css/simplepay.css');
    $this->context->controller->addJS(_MODULE_DIR_.$this->name.'/views/js/displaypayment.js');
    $this->context->smarty->assign(
        array(
         'this_path' => $this->_path,
         'validation_link' => $this->context->link->getModuleLink($this->name, 'validation', array(), true),
        )
    );
    return $this->display(__FILE__, 'paynetz.tpl');
}

	
	


}
