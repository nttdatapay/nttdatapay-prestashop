<?php
require_once 'AtomAES.php';

class PaynetzResponseModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::initContent()
	 */
	public function initContent()
	{
		parent::initContent();

		$cart = $this->context->cart;
		
			
		if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
			Tools::redirect('index.php?controller=order&step=1');

		// Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
		$authorized = false;
		foreach (Module::getPaymentModules() as $module)
			if ($module['name'] == 'paynetz')
			{
				$authorized = true;
				break;
			}
		if (!$authorized)
			die($this->module->l('This payment method is not available.', 'validation'));

		$customer = new Customer($cart->id_customer);
		if (!Validate::isLoadedObject($customer))
			Tools::redirect('index.php?controller=order&step=1');

		$currency = $this->context->currency;
		$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
		$mailVars = array(
			
		);
		
        $resHashCode=Tools::safeOutput(Configuration::get('PAYNETZ_API_RES_HASHCODE'));
        $reqEncKey = Tools::safeOutput(Configuration::get('PAYNETZ_API_REQ_ENCKEY'));
        $reqResKey = Tools::safeOutput(Configuration::get('PAYNETZ_API_RES_DECKEY'));
        $reqReqIvKey = Tools::safeOutput(Configuration::get('PAYNETZ_API_REQ_IVKEY'));
        $reqResIvKey = Tools::safeOutput(Configuration::get('PAYNETZ_API_RES_IVKEY'));
		
		
		    $atomenc = new AtomAES();
			$decrypted = $atomenc->decrypt($_POST['encData'], $reqResKey, $reqResIvKey);
			$dec_response = explode('&', $decrypted); //change & to | for production
		
			
			$jsonData = json_decode($dec_response[0], true);
			
			$statuscode = $jsonData['payInstrument']['responseDetails']['statusCode'];

			if($statuscode == "OTS0000")
			{
				//For ref 
				// http://localhost:8081/prestashop_1.7.8.1/en/order-confirmation?id_cart=40&id_module=14&id_order=29&key=f58a45a7901681de78796ea699de5282

				// "http://localhost:8081/prestashop_1.7.8.1/en/order-confirmation?id_cart=41&id_module=35&id_order=30&key=a457c273010abe2ecd3b7671ad0c4917"


				$id_order =  Db::getInstance()->getRow(' SELECT * FROM '._DB_PREFIX_.'orders WHERE id_customer = '.$cart->id_customer.' ORDER BY id_order DESC ');
				// $id_order =  Db::getInstance()->getRow(' SELECT * FROM '._DB_PREFIX_.'orders WHERE id_cart = '.$cart->id.' ORDER BY id_order DESC ');
				
				
				$this->module->validateOrder($cart->id, Configuration::get('PS_OS_PAYMENT'), $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key);
				// Tools::redirectLink(__PS_BASE_URI__.'index.php?controller=order-detail&id_order='.(int)$this->module->currentOrder);
				Tools::redirectLink(__PS_BASE_URI__ . 'order-confirmation.php?id_cart=' . $cart->id . '&id_module=' . $this->module->id . '&id_order=' . (int)$id_order['id_order'] . '&key=' . $customer->secure_key);
			}
			else
			{
				echo("<br>failed:".$statuscode);
				$this->module->validateOrder(intval($cart->id), _PS_OS_ERROR_, $total, $this->module->displayName, $this->l('Payment closed expired or closed cancelled'));
				$id_order = Order::getOrderByCartId(intval($cart->id));
				//Tools::redirectLink(__PS_BASE_URI__ . 'index.php?controller=order-detail&id_cart=' . $cart->id .'&id_module='. $this->id .'&id_order=' . $id_order . '&key=' . $customer->secure_key);
				Tools::redirectLink(__PS_BASE_URI__ . 'order-confirmation.php?id_cart=' . $cart->id . '&id_module=' . $this->module->id . '&id_order=' . $id_order['id_order'] . '&key=' . $customer->secure_key);
			}
			
	}

    function validateResponse($responseParams, $resHashCode)
    {
        // $str = $responseParams["mmp_txn"].$responseParams["mer_txn"].$responseParams["f_code"].$responseParams["prod"].$responseParams["discriminator"].$responseParams["amt"].$responseParams["bank_txn"];
        // $signature =  hash_hmac("sha512",$str,$resHashCode,false);
        // if($signature == $responseParams["signature"]){
        //     return true;
        // } else {
        //     return false;
        // }
	}

	
}
